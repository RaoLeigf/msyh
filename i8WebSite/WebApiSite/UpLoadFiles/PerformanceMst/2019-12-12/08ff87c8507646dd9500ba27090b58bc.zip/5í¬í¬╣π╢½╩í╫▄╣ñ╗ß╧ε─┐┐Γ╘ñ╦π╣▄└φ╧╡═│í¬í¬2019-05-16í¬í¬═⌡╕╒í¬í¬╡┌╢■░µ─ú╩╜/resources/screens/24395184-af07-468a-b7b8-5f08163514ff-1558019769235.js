jQuery("#simulation")
  .on("click", ".s-24395184-af07-468a-b7b8-5f08163514ff .click", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Rectangle_11")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/c00b8e46-c737-44c6-9d6b-b7c26e0c603a"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Text_16")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/c00b8e46-c737-44c6-9d6b-b7c26e0c603a"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_4")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/bb4823ca-472b-4955-ba8b-cf8e84e19c74"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_5")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/0fccf74b-aac1-42d8-9169-497c3efdd107"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_12")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/6ba5f2d2-b295-4972-b77a-5af9846574c0"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_13")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/bde4fdc1-5ec4-41fc-9850-3bbdc40e50ea"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_14")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/24395184-af07-468a-b7b8-5f08163514ff"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_15")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/7b1b6ddd-3e84-4993-abcb-2be0df5373a4"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_19")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/6f1a1d78-dbee-4e83-bc04-d427471e7f5c"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Text_31")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/0642df7d-5b05-409b-8960-a73bdca46748"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Text_33")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/4d6fd2a2-9170-437e-b095-a6af184b6a8f"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_5")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": "#s-Group_8"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_28")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/d12245cc-1680-458d-89dd-4f0d7fb22724"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("click", ".s-24395184-af07-468a-b7b8-5f08163514ff .toggle", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Image_5")) {
      if(jFirer.data("jimHasToggle")) {
        jFirer.removeData("jimHasToggle");
        jEvent.undoCases(jFirer);
      } else {
        jFirer.data("jimHasToggle", true);
        event.backupState = true;
        event.target = jFirer;
        cases = [
          {
            "blocks": [
              {
                "actions": [
                  {
                    "action": "jimHide",
                    "parameter": {
                      "target": "#s-Group_8"
                    },
                    "exectype": "serial",
                    "delay": 0
                  }
                ]
              }
            ],
            "exectype": "serial",
            "delay": 0
          }
        ];
        jEvent.launchCases(cases);
      }
    }
  })
  .on("mouseenter dragenter", ".s-24395184-af07-468a-b7b8-5f08163514ff .mouseenter", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getDirectEventFirer(this);
    if(jFirer.is("#s-Rectangle_4")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-24395184-af07-468a-b7b8-5f08163514ff #s-Rectangle_4": {
                      "attributes": {
                        "background-color": "#1A69D0",
                        "background-image": "none",
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1A69D0",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1A69D0",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1A69D0",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1A69D0",
                        "border-radius": "0px 0px 0px 0px"
                      }
                    }
                  },{
                    "#s-24395184-af07-468a-b7b8-5f08163514ff #s-Rectangle_4": {
                      "attributes-ie": {
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1A69D0",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1A69D0",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1A69D0",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1A69D0",
                        "border-radius": "0px 0px 0px 0px",
                        "-pie-background": "#1A69D0",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_5")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-24395184-af07-468a-b7b8-5f08163514ff #s-Rectangle_5": {
                      "attributes": {
                        "background-color": "#1A69D0",
                        "background-image": "none",
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1A69D0",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1A69D0",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1A69D0",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1A69D0",
                        "border-radius": "0px 0px 0px 0px"
                      }
                    }
                  },{
                    "#s-24395184-af07-468a-b7b8-5f08163514ff #s-Rectangle_5": {
                      "attributes-ie": {
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1A69D0",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1A69D0",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1A69D0",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1A69D0",
                        "border-radius": "0px 0px 0px 0px",
                        "-pie-background": "#1A69D0",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_12")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-24395184-af07-468a-b7b8-5f08163514ff #s-Rectangle_12": {
                      "attributes": {
                        "background-color": "#1A69D0",
                        "background-image": "none",
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1A69D0",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1A69D0",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1A69D0",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1A69D0",
                        "border-radius": "0px 0px 0px 0px"
                      }
                    }
                  },{
                    "#s-24395184-af07-468a-b7b8-5f08163514ff #s-Rectangle_12": {
                      "attributes-ie": {
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1A69D0",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1A69D0",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1A69D0",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1A69D0",
                        "border-radius": "0px 0px 0px 0px",
                        "-pie-background": "#1A69D0",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_13")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-24395184-af07-468a-b7b8-5f08163514ff #s-Rectangle_13": {
                      "attributes": {
                        "background-color": "#1A69D0",
                        "background-image": "none",
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1A69D0",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1A69D0",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1A69D0",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1A69D0",
                        "border-radius": "0px 0px 0px 0px"
                      }
                    }
                  },{
                    "#s-24395184-af07-468a-b7b8-5f08163514ff #s-Rectangle_13": {
                      "attributes-ie": {
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1A69D0",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1A69D0",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1A69D0",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1A69D0",
                        "border-radius": "0px 0px 0px 0px",
                        "-pie-background": "#1A69D0",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_15")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-24395184-af07-468a-b7b8-5f08163514ff #s-Rectangle_15": {
                      "attributes": {
                        "background-color": "#1A69D0",
                        "background-image": "none",
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1A69D0",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1A69D0",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1A69D0",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1A69D0",
                        "border-radius": "0px 0px 0px 0px"
                      }
                    }
                  },{
                    "#s-24395184-af07-468a-b7b8-5f08163514ff #s-Rectangle_15": {
                      "attributes-ie": {
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1A69D0",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1A69D0",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1A69D0",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1A69D0",
                        "border-radius": "0px 0px 0px 0px",
                        "-pie-background": "#1A69D0",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_23")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-24395184-af07-468a-b7b8-5f08163514ff #s-Rectangle_23": {
                      "attributes": {
                        "line-height": "27px",
                        "font-size": "14.0pt",
                        "font-family": "Arial,Arial"
                      }
                    }
                  },{
                    "#s-24395184-af07-468a-b7b8-5f08163514ff #s-Rectangle_23 .valign": {
                      "attributes": {
                        "vertical-align": "middle",
                        "text-align": "center"
                      }
                    }
                  },{
                    "#s-24395184-af07-468a-b7b8-5f08163514ff #s-Rectangle_23 span": {
                      "attributes": {
                        "color": "#FF9900",
                        "text-align": "center",
                        "text-decoration": "none",
                        "font-family": "Arial,Arial",
                        "font-size": "14.0pt",
                        "font-style": "normal",
                        "font-weight": "700"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_26")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-24395184-af07-468a-b7b8-5f08163514ff #s-Rectangle_26": {
                      "attributes": {
                        "line-height": "23px",
                        "font-size": "12.0pt",
                        "font-family": "Arial,Arial"
                      }
                    }
                  },{
                    "#s-24395184-af07-468a-b7b8-5f08163514ff #s-Rectangle_26 .valign": {
                      "attributes": {
                        "vertical-align": "middle",
                        "text-align": "center"
                      }
                    }
                  },{
                    "#s-24395184-af07-468a-b7b8-5f08163514ff #s-Rectangle_26 span": {
                      "attributes": {
                        "color": "#FF9900",
                        "text-align": "center",
                        "text-decoration": "none",
                        "font-family": "Arial,Arial",
                        "font-size": "12.0pt",
                        "font-style": "normal",
                        "font-weight": "400"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_28")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-24395184-af07-468a-b7b8-5f08163514ff #s-Rectangle_28": {
                      "attributes": {
                        "line-height": "23px",
                        "font-size": "12.0pt",
                        "font-family": "Arial,Arial"
                      }
                    }
                  },{
                    "#s-24395184-af07-468a-b7b8-5f08163514ff #s-Rectangle_28 .valign": {
                      "attributes": {
                        "vertical-align": "middle",
                        "text-align": "center"
                      }
                    }
                  },{
                    "#s-24395184-af07-468a-b7b8-5f08163514ff #s-Rectangle_28 span": {
                      "attributes": {
                        "color": "#FF9900",
                        "text-align": "center",
                        "text-decoration": "none",
                        "font-family": "Arial,Arial",
                        "font-size": "12.0pt",
                        "font-style": "normal",
                        "font-weight": "400"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("mouseleave dragleave", ".s-24395184-af07-468a-b7b8-5f08163514ff .mouseleave", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getDirectEventFirer(this);
    if(jFirer.is("#s-Rectangle_4") && (jQuery(document.elementFromPoint(event.clientX, event.clientY)).closest("#s-Rectangle_4").length === 0 || jQuery(document.elementFromPoint(event.clientX, event.clientY)).closest("#s-Rectangle_4") !== jFirer)) {
      event.stopPropagation();
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-24395184-af07-468a-b7b8-5f08163514ff #s-Rectangle_4": {
                      "attributes": {
                        "background-color": "#1F6CFC",
                        "background-image": "none",
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1F6CFC",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1F6CFC",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1F6CFC",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1F6CFC",
                        "border-radius": "0px 0px 0px 0px"
                      }
                    }
                  },{
                    "#s-24395184-af07-468a-b7b8-5f08163514ff #s-Rectangle_4": {
                      "attributes-ie": {
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1F6CFC",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1F6CFC",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1F6CFC",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1F6CFC",
                        "border-radius": "0px 0px 0px 0px",
                        "-pie-background": "#1F6CFC",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_5") && (jQuery(document.elementFromPoint(event.clientX, event.clientY)).closest("#s-Rectangle_5").length === 0 || jQuery(document.elementFromPoint(event.clientX, event.clientY)).closest("#s-Rectangle_5") !== jFirer)) {
      event.stopPropagation();
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-24395184-af07-468a-b7b8-5f08163514ff #s-Rectangle_5": {
                      "attributes": {
                        "background-color": "#1F6CFC",
                        "background-image": "none",
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1F6CFC",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1F6CFC",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1F6CFC",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1F6CFC",
                        "border-radius": "0px 0px 0px 0px"
                      }
                    }
                  },{
                    "#s-24395184-af07-468a-b7b8-5f08163514ff #s-Rectangle_5": {
                      "attributes-ie": {
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1F6CFC",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1F6CFC",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1F6CFC",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1F6CFC",
                        "border-radius": "0px 0px 0px 0px",
                        "-pie-background": "#1F6CFC",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_12") && (jQuery(document.elementFromPoint(event.clientX, event.clientY)).closest("#s-Rectangle_12").length === 0 || jQuery(document.elementFromPoint(event.clientX, event.clientY)).closest("#s-Rectangle_12") !== jFirer)) {
      event.stopPropagation();
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-24395184-af07-468a-b7b8-5f08163514ff #s-Rectangle_12": {
                      "attributes": {
                        "background-color": "#1F6CFC",
                        "background-image": "none",
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1F6CFC",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1F6CFC",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1F6CFC",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1F6CFC",
                        "border-radius": "0px 0px 0px 0px"
                      }
                    }
                  },{
                    "#s-24395184-af07-468a-b7b8-5f08163514ff #s-Rectangle_12": {
                      "attributes-ie": {
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1F6CFC",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1F6CFC",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1F6CFC",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1F6CFC",
                        "border-radius": "0px 0px 0px 0px",
                        "-pie-background": "#1F6CFC",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_13") && (jQuery(document.elementFromPoint(event.clientX, event.clientY)).closest("#s-Rectangle_13").length === 0 || jQuery(document.elementFromPoint(event.clientX, event.clientY)).closest("#s-Rectangle_13") !== jFirer)) {
      event.stopPropagation();
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-24395184-af07-468a-b7b8-5f08163514ff #s-Rectangle_13": {
                      "attributes": {
                        "background-color": "#1F6CFC",
                        "background-image": "none",
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1F6CFC",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1F6CFC",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1F6CFC",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1F6CFC",
                        "border-radius": "0px 0px 0px 0px"
                      }
                    }
                  },{
                    "#s-24395184-af07-468a-b7b8-5f08163514ff #s-Rectangle_13": {
                      "attributes-ie": {
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1F6CFC",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1F6CFC",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1F6CFC",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1F6CFC",
                        "border-radius": "0px 0px 0px 0px",
                        "-pie-background": "#1F6CFC",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_15") && (jQuery(document.elementFromPoint(event.clientX, event.clientY)).closest("#s-Rectangle_15").length === 0 || jQuery(document.elementFromPoint(event.clientX, event.clientY)).closest("#s-Rectangle_15") !== jFirer)) {
      event.stopPropagation();
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-24395184-af07-468a-b7b8-5f08163514ff #s-Rectangle_15": {
                      "attributes": {
                        "background-color": "#1F6CFC",
                        "background-image": "none",
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1F6CFC",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1F6CFC",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1F6CFC",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1F6CFC",
                        "border-radius": "0px 0px 0px 0px"
                      }
                    }
                  },{
                    "#s-24395184-af07-468a-b7b8-5f08163514ff #s-Rectangle_15": {
                      "attributes-ie": {
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1F6CFC",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1F6CFC",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1F6CFC",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1F6CFC",
                        "border-radius": "0px 0px 0px 0px",
                        "-pie-background": "#1F6CFC",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_23") && (jQuery(document.elementFromPoint(event.clientX, event.clientY)).closest("#s-Rectangle_23").length === 0 || jQuery(document.elementFromPoint(event.clientX, event.clientY)).closest("#s-Rectangle_23") !== jFirer)) {
      event.stopPropagation();
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-24395184-af07-468a-b7b8-5f08163514ff #s-Rectangle_23": {
                      "attributes": {
                        "line-height": "27px",
                        "font-size": "14.0pt",
                        "font-family": "Arial,Arial"
                      }
                    }
                  },{
                    "#s-24395184-af07-468a-b7b8-5f08163514ff #s-Rectangle_23 .valign": {
                      "attributes": {
                        "vertical-align": "middle",
                        "text-align": "center"
                      }
                    }
                  },{
                    "#s-24395184-af07-468a-b7b8-5f08163514ff #s-Rectangle_23 span": {
                      "attributes": {
                        "color": "#FFFFFF",
                        "text-align": "center",
                        "text-decoration": "none",
                        "font-family": "Arial,Arial",
                        "font-size": "14.0pt",
                        "font-style": "normal",
                        "font-weight": "700"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_26") && (jQuery(document.elementFromPoint(event.clientX, event.clientY)).closest("#s-Rectangle_26").length === 0 || jQuery(document.elementFromPoint(event.clientX, event.clientY)).closest("#s-Rectangle_26") !== jFirer)) {
      event.stopPropagation();
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-24395184-af07-468a-b7b8-5f08163514ff #s-Rectangle_26": {
                      "attributes": {
                        "line-height": "23px",
                        "font-size": "12.0pt",
                        "font-family": "Arial,Arial"
                      }
                    }
                  },{
                    "#s-24395184-af07-468a-b7b8-5f08163514ff #s-Rectangle_26 .valign": {
                      "attributes": {
                        "vertical-align": "middle",
                        "text-align": "center"
                      }
                    }
                  },{
                    "#s-24395184-af07-468a-b7b8-5f08163514ff #s-Rectangle_26 span": {
                      "attributes": {
                        "color": "#FFFFFF",
                        "text-align": "center",
                        "text-decoration": "none",
                        "font-family": "Arial,Arial",
                        "font-size": "12.0pt",
                        "font-style": "normal",
                        "font-weight": "400"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_28") && (jQuery(document.elementFromPoint(event.clientX, event.clientY)).closest("#s-Rectangle_28").length === 0 || jQuery(document.elementFromPoint(event.clientX, event.clientY)).closest("#s-Rectangle_28") !== jFirer)) {
      event.stopPropagation();
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-24395184-af07-468a-b7b8-5f08163514ff #s-Rectangle_28": {
                      "attributes": {
                        "line-height": "23px",
                        "font-size": "12.0pt",
                        "font-family": "Arial,Arial"
                      }
                    }
                  },{
                    "#s-24395184-af07-468a-b7b8-5f08163514ff #s-Rectangle_28 .valign": {
                      "attributes": {
                        "vertical-align": "middle",
                        "text-align": "center"
                      }
                    }
                  },{
                    "#s-24395184-af07-468a-b7b8-5f08163514ff #s-Rectangle_28 span": {
                      "attributes": {
                        "color": "#FFFFFF",
                        "text-align": "center",
                        "text-decoration": "none",
                        "font-family": "Arial,Arial",
                        "font-size": "12.0pt",
                        "font-style": "normal",
                        "font-weight": "400"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  });