jQuery("#simulation")
  .on("click", ".s-8a100f90-ef36-420f-9afe-5db1e2f6de7e .click", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Text_17")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/d12245cc-1680-458d-89dd-4f0d7fb22724"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Text_74")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/0d77af63-6103-4b2e-a961-304e6d044f13"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_19")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/6ba5f2d2-b295-4972-b77a-5af9846574c0"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_6")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/bb4823ca-472b-4955-ba8b-cf8e84e19c74"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_13")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/0fccf74b-aac1-42d8-9169-497c3efdd107"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_14")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/6ba5f2d2-b295-4972-b77a-5af9846574c0"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_15")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/ed3cf243-413b-4b1f-aa93-59a6205edcd1"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_16")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/24395184-af07-468a-b7b8-5f08163514ff"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_17")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/7b1b6ddd-3e84-4993-abcb-2be0df5373a4"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_18")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/6f1a1d78-dbee-4e83-bc04-d427471e7f5c"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Text_cell_19")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/7b1b6ddd-3e84-4993-abcb-2be0df5373a4"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_106")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/0642df7d-5b05-409b-8960-a73bdca46748"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_193")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/dde14099-b39d-4a24-9e57-4af464d717cb"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_192")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/14333d70-fe78-4428-8de2-aaa35c52101b"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_194")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/abd4a37b-b860-4593-81bf-f9a238b39af3"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Text_4")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/3adee4be-c61b-4802-890d-d997541fed7f"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_197")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/3f9c8524-979b-4b79-a8b6-f7d0acc4a058"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_40")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/3adee4be-c61b-4802-890d-d997541fed7f"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Text_21")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/551abd7a-e54a-4157-94ec-b12239568b47"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("mouseenter dragenter", ".s-8a100f90-ef36-420f-9afe-5db1e2f6de7e .mouseenter", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getDirectEventFirer(this);
    if(jFirer.is("#s-Rectangle_6")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-8a100f90-ef36-420f-9afe-5db1e2f6de7e #s-Rectangle_6": {
                      "attributes": {
                        "background-color": "#1A69D0",
                        "background-image": "none",
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1A69D0",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1A69D0",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1A69D0",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1A69D0",
                        "border-radius": "0px 0px 0px 0px"
                      }
                    }
                  },{
                    "#s-8a100f90-ef36-420f-9afe-5db1e2f6de7e #s-Rectangle_6": {
                      "attributes-ie": {
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1A69D0",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1A69D0",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1A69D0",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1A69D0",
                        "border-radius": "0px 0px 0px 0px",
                        "-pie-background": "#1A69D0",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_13")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-8a100f90-ef36-420f-9afe-5db1e2f6de7e #s-Rectangle_13": {
                      "attributes": {
                        "background-color": "#1A69D0",
                        "background-image": "none",
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1A69D0",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1A69D0",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1A69D0",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1A69D0",
                        "border-radius": "0px 0px 0px 0px"
                      }
                    }
                  },{
                    "#s-8a100f90-ef36-420f-9afe-5db1e2f6de7e #s-Rectangle_13": {
                      "attributes-ie": {
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1A69D0",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1A69D0",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1A69D0",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1A69D0",
                        "border-radius": "0px 0px 0px 0px",
                        "-pie-background": "#1A69D0",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_14")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-8a100f90-ef36-420f-9afe-5db1e2f6de7e #s-Rectangle_14": {
                      "attributes": {
                        "background-color": "#1A69D0",
                        "background-image": "none",
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1A69D0",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1A69D0",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1A69D0",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1A69D0",
                        "border-radius": "0px 0px 0px 0px"
                      }
                    }
                  },{
                    "#s-8a100f90-ef36-420f-9afe-5db1e2f6de7e #s-Rectangle_14": {
                      "attributes-ie": {
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1A69D0",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1A69D0",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1A69D0",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1A69D0",
                        "border-radius": "0px 0px 0px 0px",
                        "-pie-background": "#1A69D0",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_16")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-8a100f90-ef36-420f-9afe-5db1e2f6de7e #s-Rectangle_16": {
                      "attributes": {
                        "background-color": "#1A69D0",
                        "background-image": "none",
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1A69D0",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1A69D0",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1A69D0",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1A69D0",
                        "border-radius": "0px 0px 0px 0px"
                      }
                    }
                  },{
                    "#s-8a100f90-ef36-420f-9afe-5db1e2f6de7e #s-Rectangle_16": {
                      "attributes-ie": {
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1A69D0",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1A69D0",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1A69D0",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1A69D0",
                        "border-radius": "0px 0px 0px 0px",
                        "-pie-background": "#1A69D0",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_17")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-8a100f90-ef36-420f-9afe-5db1e2f6de7e #s-Rectangle_17": {
                      "attributes": {
                        "background-color": "#1A69D0",
                        "background-image": "none",
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1A69D0",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1A69D0",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1A69D0",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1A69D0",
                        "border-radius": "0px 0px 0px 0px"
                      }
                    }
                  },{
                    "#s-8a100f90-ef36-420f-9afe-5db1e2f6de7e #s-Rectangle_17": {
                      "attributes-ie": {
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1A69D0",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1A69D0",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1A69D0",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1A69D0",
                        "border-radius": "0px 0px 0px 0px",
                        "-pie-background": "#1A69D0",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_52")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": "#s-Callout_8"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("mouseleave dragleave", ".s-8a100f90-ef36-420f-9afe-5db1e2f6de7e .mouseleave", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getDirectEventFirer(this);
    if(jFirer.is("#s-Rectangle_6") && (jQuery(document.elementFromPoint(event.clientX, event.clientY)).closest("#s-Rectangle_6").length === 0 || jQuery(document.elementFromPoint(event.clientX, event.clientY)).closest("#s-Rectangle_6") !== jFirer)) {
      event.stopPropagation();
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-8a100f90-ef36-420f-9afe-5db1e2f6de7e #s-Rectangle_6": {
                      "attributes": {
                        "background-color": "#1F6CFC",
                        "background-image": "none",
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1F6CFC",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1F6CFC",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1F6CFC",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1F6CFC",
                        "border-radius": "0px 0px 0px 0px"
                      }
                    }
                  },{
                    "#s-8a100f90-ef36-420f-9afe-5db1e2f6de7e #s-Rectangle_6": {
                      "attributes-ie": {
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1F6CFC",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1F6CFC",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1F6CFC",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1F6CFC",
                        "border-radius": "0px 0px 0px 0px",
                        "-pie-background": "#1F6CFC",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_13") && (jQuery(document.elementFromPoint(event.clientX, event.clientY)).closest("#s-Rectangle_13").length === 0 || jQuery(document.elementFromPoint(event.clientX, event.clientY)).closest("#s-Rectangle_13") !== jFirer)) {
      event.stopPropagation();
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-8a100f90-ef36-420f-9afe-5db1e2f6de7e #s-Rectangle_13": {
                      "attributes": {
                        "background-color": "#1F6CFC",
                        "background-image": "none",
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1F6CFC",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1F6CFC",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1F6CFC",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1F6CFC",
                        "border-radius": "0px 0px 0px 0px"
                      }
                    }
                  },{
                    "#s-8a100f90-ef36-420f-9afe-5db1e2f6de7e #s-Rectangle_13": {
                      "attributes-ie": {
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1F6CFC",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1F6CFC",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1F6CFC",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1F6CFC",
                        "border-radius": "0px 0px 0px 0px",
                        "-pie-background": "#1F6CFC",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_14") && (jQuery(document.elementFromPoint(event.clientX, event.clientY)).closest("#s-Rectangle_14").length === 0 || jQuery(document.elementFromPoint(event.clientX, event.clientY)).closest("#s-Rectangle_14") !== jFirer)) {
      event.stopPropagation();
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-8a100f90-ef36-420f-9afe-5db1e2f6de7e #s-Rectangle_14": {
                      "attributes": {
                        "background-color": "#1F6CFC",
                        "background-image": "none",
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1F6CFC",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1F6CFC",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1F6CFC",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1F6CFC",
                        "border-radius": "0px 0px 0px 0px"
                      }
                    }
                  },{
                    "#s-8a100f90-ef36-420f-9afe-5db1e2f6de7e #s-Rectangle_14": {
                      "attributes-ie": {
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1F6CFC",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1F6CFC",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1F6CFC",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1F6CFC",
                        "border-radius": "0px 0px 0px 0px",
                        "-pie-background": "#1F6CFC",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_16") && (jQuery(document.elementFromPoint(event.clientX, event.clientY)).closest("#s-Rectangle_16").length === 0 || jQuery(document.elementFromPoint(event.clientX, event.clientY)).closest("#s-Rectangle_16") !== jFirer)) {
      event.stopPropagation();
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-8a100f90-ef36-420f-9afe-5db1e2f6de7e #s-Rectangle_16": {
                      "attributes": {
                        "background-color": "#1F6CFC",
                        "background-image": "none",
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1F6CFC",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1F6CFC",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1F6CFC",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1F6CFC",
                        "border-radius": "0px 0px 0px 0px"
                      }
                    }
                  },{
                    "#s-8a100f90-ef36-420f-9afe-5db1e2f6de7e #s-Rectangle_16": {
                      "attributes-ie": {
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1F6CFC",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1F6CFC",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1F6CFC",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1F6CFC",
                        "border-radius": "0px 0px 0px 0px",
                        "-pie-background": "#1F6CFC",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_17") && (jQuery(document.elementFromPoint(event.clientX, event.clientY)).closest("#s-Rectangle_17").length === 0 || jQuery(document.elementFromPoint(event.clientX, event.clientY)).closest("#s-Rectangle_17") !== jFirer)) {
      event.stopPropagation();
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-8a100f90-ef36-420f-9afe-5db1e2f6de7e #s-Rectangle_17": {
                      "attributes": {
                        "background-color": "#1F6CFC",
                        "background-image": "none",
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1F6CFC",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1F6CFC",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1F6CFC",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1F6CFC",
                        "border-radius": "0px 0px 0px 0px"
                      }
                    }
                  },{
                    "#s-8a100f90-ef36-420f-9afe-5db1e2f6de7e #s-Rectangle_17": {
                      "attributes-ie": {
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1F6CFC",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1F6CFC",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1F6CFC",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1F6CFC",
                        "border-radius": "0px 0px 0px 0px",
                        "-pie-background": "#1F6CFC",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_52") && (jQuery(document.elementFromPoint(event.clientX, event.clientY)).closest("#s-Image_52").length === 0 || jQuery(document.elementFromPoint(event.clientX, event.clientY)).closest("#s-Image_52") !== jFirer)) {
      event.stopPropagation();
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": "#s-Callout_8"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  });