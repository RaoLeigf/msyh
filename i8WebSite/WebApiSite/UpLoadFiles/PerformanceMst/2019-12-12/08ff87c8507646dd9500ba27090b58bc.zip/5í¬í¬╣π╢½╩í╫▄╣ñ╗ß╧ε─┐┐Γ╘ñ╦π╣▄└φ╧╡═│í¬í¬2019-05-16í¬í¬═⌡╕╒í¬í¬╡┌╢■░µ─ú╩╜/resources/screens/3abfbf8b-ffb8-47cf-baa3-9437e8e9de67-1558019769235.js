jQuery("#simulation")
  .on("click", ".s-3abfbf8b-ffb8-47cf-baa3-9437e8e9de67 .click", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Text_17")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/d12245cc-1680-458d-89dd-4f0d7fb22724"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_15")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/3abfbf8b-ffb8-47cf-baa3-9437e8e9de67"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Text_73")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/cbe5589c-6196-4d94-8b5a-82cd4a19c0f3"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Text_74")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/73b2ff70-d445-4611-821a-b7e986528491"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Text_75")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/12093d73-0527-4ed5-b220-7634fcc400ae"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Text_76")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/d7a8514a-0cff-41d6-9500-deba92c5d3f4"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Text_77")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/50f19d52-0286-4762-9336-f2c83fc7a802"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_19")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/6ba5f2d2-b295-4972-b77a-5af9846574c0"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_6")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/bb4823ca-472b-4955-ba8b-cf8e84e19c74"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_13")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/0fccf74b-aac1-42d8-9169-497c3efdd107"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_14")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/6ba5f2d2-b295-4972-b77a-5af9846574c0"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_15")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/ed3cf243-413b-4b1f-aa93-59a6205edcd1"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_16")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/24395184-af07-468a-b7b8-5f08163514ff"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_17")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/7b1b6ddd-3e84-4993-abcb-2be0df5373a4"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_18")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/6f1a1d78-dbee-4e83-bc04-d427471e7f5c"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Text_cell_19")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/bda50c20-da1c-4413-9440-371fe2caa29e"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("mouseenter dragenter", ".s-3abfbf8b-ffb8-47cf-baa3-9437e8e9de67 .mouseenter", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getDirectEventFirer(this);
    if(jFirer.is("#s-Rectangle_6")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-3abfbf8b-ffb8-47cf-baa3-9437e8e9de67 #s-Rectangle_6": {
                      "attributes": {
                        "background-color": "#1A69D0",
                        "background-image": "none",
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1A69D0",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1A69D0",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1A69D0",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1A69D0",
                        "border-radius": "0px 0px 0px 0px"
                      }
                    }
                  },{
                    "#s-3abfbf8b-ffb8-47cf-baa3-9437e8e9de67 #s-Rectangle_6": {
                      "attributes-ie": {
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1A69D0",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1A69D0",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1A69D0",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1A69D0",
                        "border-radius": "0px 0px 0px 0px",
                        "-pie-background": "#1A69D0",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_13")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-3abfbf8b-ffb8-47cf-baa3-9437e8e9de67 #s-Rectangle_13": {
                      "attributes": {
                        "background-color": "#1A69D0",
                        "background-image": "none",
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1A69D0",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1A69D0",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1A69D0",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1A69D0",
                        "border-radius": "0px 0px 0px 0px"
                      }
                    }
                  },{
                    "#s-3abfbf8b-ffb8-47cf-baa3-9437e8e9de67 #s-Rectangle_13": {
                      "attributes-ie": {
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1A69D0",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1A69D0",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1A69D0",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1A69D0",
                        "border-radius": "0px 0px 0px 0px",
                        "-pie-background": "#1A69D0",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_14")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-3abfbf8b-ffb8-47cf-baa3-9437e8e9de67 #s-Rectangle_14": {
                      "attributes": {
                        "background-color": "#1A69D0",
                        "background-image": "none",
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1A69D0",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1A69D0",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1A69D0",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1A69D0",
                        "border-radius": "0px 0px 0px 0px"
                      }
                    }
                  },{
                    "#s-3abfbf8b-ffb8-47cf-baa3-9437e8e9de67 #s-Rectangle_14": {
                      "attributes-ie": {
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1A69D0",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1A69D0",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1A69D0",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1A69D0",
                        "border-radius": "0px 0px 0px 0px",
                        "-pie-background": "#1A69D0",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_16")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-3abfbf8b-ffb8-47cf-baa3-9437e8e9de67 #s-Rectangle_16": {
                      "attributes": {
                        "background-color": "#1A69D0",
                        "background-image": "none",
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1A69D0",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1A69D0",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1A69D0",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1A69D0",
                        "border-radius": "0px 0px 0px 0px"
                      }
                    }
                  },{
                    "#s-3abfbf8b-ffb8-47cf-baa3-9437e8e9de67 #s-Rectangle_16": {
                      "attributes-ie": {
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1A69D0",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1A69D0",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1A69D0",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1A69D0",
                        "border-radius": "0px 0px 0px 0px",
                        "-pie-background": "#1A69D0",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_17")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-3abfbf8b-ffb8-47cf-baa3-9437e8e9de67 #s-Rectangle_17": {
                      "attributes": {
                        "background-color": "#1A69D0",
                        "background-image": "none",
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1A69D0",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1A69D0",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1A69D0",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1A69D0",
                        "border-radius": "0px 0px 0px 0px"
                      }
                    }
                  },{
                    "#s-3abfbf8b-ffb8-47cf-baa3-9437e8e9de67 #s-Rectangle_17": {
                      "attributes-ie": {
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1A69D0",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1A69D0",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1A69D0",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1A69D0",
                        "border-radius": "0px 0px 0px 0px",
                        "-pie-background": "#1A69D0",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("mouseleave dragleave", ".s-3abfbf8b-ffb8-47cf-baa3-9437e8e9de67 .mouseleave", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getDirectEventFirer(this);
    if(jFirer.is("#s-Rectangle_6") && (jQuery(document.elementFromPoint(event.clientX, event.clientY)).closest("#s-Rectangle_6").length === 0 || jQuery(document.elementFromPoint(event.clientX, event.clientY)).closest("#s-Rectangle_6") !== jFirer)) {
      event.stopPropagation();
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-3abfbf8b-ffb8-47cf-baa3-9437e8e9de67 #s-Rectangle_6": {
                      "attributes": {
                        "background-color": "#1F6CFC",
                        "background-image": "none",
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1F6CFC",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1F6CFC",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1F6CFC",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1F6CFC",
                        "border-radius": "0px 0px 0px 0px"
                      }
                    }
                  },{
                    "#s-3abfbf8b-ffb8-47cf-baa3-9437e8e9de67 #s-Rectangle_6": {
                      "attributes-ie": {
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1F6CFC",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1F6CFC",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1F6CFC",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1F6CFC",
                        "border-radius": "0px 0px 0px 0px",
                        "-pie-background": "#1F6CFC",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_13") && (jQuery(document.elementFromPoint(event.clientX, event.clientY)).closest("#s-Rectangle_13").length === 0 || jQuery(document.elementFromPoint(event.clientX, event.clientY)).closest("#s-Rectangle_13") !== jFirer)) {
      event.stopPropagation();
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-3abfbf8b-ffb8-47cf-baa3-9437e8e9de67 #s-Rectangle_13": {
                      "attributes": {
                        "background-color": "#1F6CFC",
                        "background-image": "none",
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1F6CFC",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1F6CFC",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1F6CFC",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1F6CFC",
                        "border-radius": "0px 0px 0px 0px"
                      }
                    }
                  },{
                    "#s-3abfbf8b-ffb8-47cf-baa3-9437e8e9de67 #s-Rectangle_13": {
                      "attributes-ie": {
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1F6CFC",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1F6CFC",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1F6CFC",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1F6CFC",
                        "border-radius": "0px 0px 0px 0px",
                        "-pie-background": "#1F6CFC",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_14") && (jQuery(document.elementFromPoint(event.clientX, event.clientY)).closest("#s-Rectangle_14").length === 0 || jQuery(document.elementFromPoint(event.clientX, event.clientY)).closest("#s-Rectangle_14") !== jFirer)) {
      event.stopPropagation();
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-3abfbf8b-ffb8-47cf-baa3-9437e8e9de67 #s-Rectangle_14": {
                      "attributes": {
                        "background-color": "#1F6CFC",
                        "background-image": "none",
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1F6CFC",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1F6CFC",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1F6CFC",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1F6CFC",
                        "border-radius": "0px 0px 0px 0px"
                      }
                    }
                  },{
                    "#s-3abfbf8b-ffb8-47cf-baa3-9437e8e9de67 #s-Rectangle_14": {
                      "attributes-ie": {
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1F6CFC",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1F6CFC",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1F6CFC",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1F6CFC",
                        "border-radius": "0px 0px 0px 0px",
                        "-pie-background": "#1F6CFC",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_16") && (jQuery(document.elementFromPoint(event.clientX, event.clientY)).closest("#s-Rectangle_16").length === 0 || jQuery(document.elementFromPoint(event.clientX, event.clientY)).closest("#s-Rectangle_16") !== jFirer)) {
      event.stopPropagation();
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-3abfbf8b-ffb8-47cf-baa3-9437e8e9de67 #s-Rectangle_16": {
                      "attributes": {
                        "background-color": "#1F6CFC",
                        "background-image": "none",
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1F6CFC",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1F6CFC",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1F6CFC",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1F6CFC",
                        "border-radius": "0px 0px 0px 0px"
                      }
                    }
                  },{
                    "#s-3abfbf8b-ffb8-47cf-baa3-9437e8e9de67 #s-Rectangle_16": {
                      "attributes-ie": {
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1F6CFC",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1F6CFC",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1F6CFC",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1F6CFC",
                        "border-radius": "0px 0px 0px 0px",
                        "-pie-background": "#1F6CFC",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_17") && (jQuery(document.elementFromPoint(event.clientX, event.clientY)).closest("#s-Rectangle_17").length === 0 || jQuery(document.elementFromPoint(event.clientX, event.clientY)).closest("#s-Rectangle_17") !== jFirer)) {
      event.stopPropagation();
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-3abfbf8b-ffb8-47cf-baa3-9437e8e9de67 #s-Rectangle_17": {
                      "attributes": {
                        "background-color": "#1F6CFC",
                        "background-image": "none",
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1F6CFC",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1F6CFC",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1F6CFC",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1F6CFC",
                        "border-radius": "0px 0px 0px 0px"
                      }
                    }
                  },{
                    "#s-3abfbf8b-ffb8-47cf-baa3-9437e8e9de67 #s-Rectangle_17": {
                      "attributes-ie": {
                        "border-top-width": "2px",
                        "border-top-style": "solid",
                        "border-top-color": "#1F6CFC",
                        "border-right-width": "2px",
                        "border-right-style": "solid",
                        "border-right-color": "#1F6CFC",
                        "border-bottom-width": "2px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#1F6CFC",
                        "border-left-width": "2px",
                        "border-left-style": "solid",
                        "border-left-color": "#1F6CFC",
                        "border-radius": "0px 0px 0px 0px",
                        "-pie-background": "#1F6CFC",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  });